package Clases;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class GUI implements ActionListener, ItemListener{

	private JFrame frame;
	private JTextField txtrespuesta;
	JButton boton2;
	JButton boton1;
	JButton boton3;
	JButton boton4;
	JButton btnSumar;
	JButton btnRestar;
	JButton btnIgual;
	String numero1, numero2;
	int resultado;
	int operacion;
	private JButton btnNewButton;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
		boton1.addActionListener(this);
		boton2.addActionListener(this);
		boton3.addActionListener(this);
		boton4.addActionListener(this);
		btnSumar.addActionListener(this);
		btnRestar.addActionListener(this);
		btnIgual.addActionListener(this);
		numero1 = numero2 = "";
		operacion = 0;
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		boton2 = new JButton("2");
		boton2.setBounds(156, 26, 117, 29);
		frame.getContentPane().add(boton2);
		
		boton1 = new JButton("1");
		boton1.setBounds(27, 26, 117, 29);
		frame.getContentPane().add(boton1);
		
		boton3 = new JButton("3");
		boton3.setBounds(27, 62, 117, 29);
		frame.getContentPane().add(boton3);
		
		boton4 = new JButton("4");
		boton4.setBounds(156, 62, 117, 29);
		frame.getContentPane().add(boton4);
		
		btnSumar = new JButton("sumar");
		btnSumar.setBounds(27, 133, 117, 29);
		frame.getContentPane().add(btnSumar);
		
	    btnRestar = new JButton("restar");
		btnRestar.setBounds(156, 133, 117, 29);
		frame.getContentPane().add(btnRestar);
		
		txtrespuesta = new JTextField();
		txtrespuesta.setBounds(84, 222, 130, 26);
		frame.getContentPane().add(txtrespuesta);
		txtrespuesta.setColumns(10);
		
		btnIgual = new JButton("=");
		btnIgual.setBounds(297, 133, 117, 29);
		frame.getContentPane().add(btnIgual);
		
		btnNewButton = new JButton("New button");
		btnNewButton.setBounds(297, 193, 117, 29);
		frame.getContentPane().add(btnNewButton);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
			}
		});
		comboBox.setBounds(309, 63, 87, 27);
		frame.getContentPane().add(comboBox);
		frame.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{frame.getContentPane()}));
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton boton = (JButton)e.getSource();
		if (boton.equals(boton1)) 
		{
			numero1 = numero1 + "1";
			txtrespuesta.setText(numero1);
			
			
		}
		if (boton.equals(boton2)) 
		{
			numero1 = numero1 + "2";
			txtrespuesta.setText(numero1);
		}
		if (boton.equals(boton3)) 
		{
			numero1 = numero1 + "3";
			txtrespuesta.setText(numero1);
		}
		if (boton.equals(boton4)) 
		{
			numero1 = numero1 + "4";
			txtrespuesta.setText(numero1);
		}
		if (boton.equals(btnSumar)) 
		{
			numero2 = numero1;
			numero1="";
			txtrespuesta.setText(numero1);
			operacion =1; //1 es suma
		}
		if (boton.equals(btnRestar)) 
		{
			numero2 = numero1;
			numero1="";
			txtrespuesta.setText(numero1);
			operacion =2; //2 es resta
		}
		if (boton.equals(btnIgual)) 
		{
			int n1,n2;
			n1 = Integer.parseInt(numero2);
			n2 = Integer.parseInt(numero1);
				
			switch(operacion) 
			{
			case 1: //suma
				resultado = n1 + n2;
				break;
			
			case 2: //resta
				resultado = n1 - n2;
				break;
			
			default:
				System.out.println("no selecciono nada");
				return; //solo el return termina el metodo
			}
			JOptionPane.showMessageDialog(null, "el resultado es: "+resultado); //1.componente con el que esta enlazado el mensaje - null es en medio de la pantalla; 2.String con el mensaje
			numero1 = "";
			numero2 = "";
			resultado = 0;
			operacion = 0;
		}
		
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
	}
}
